<template>
    <h1>Register Route</h1>
</template>