<template>
    <footer id="custom-footer">
        <span class="mr-4"> &copy; 2019 Cory Morgan</span>
        <span class="mr-4"> Privacy Policy</span>
        <span>Terms</span>
    </footer>
</template>